The supplementary files are consisting of following parts:

# Experimental Data
The data of the experiment exploring the relationship of used filler and elastomer type on the relative inductance change per gram of weight applied.
Following file contains the raw and the normalized data:
Experiment_Inductance_vs_Weight_Ecoflex_Moldstar_incremental_raw.xlsx
Following file contains the the statistical data of the measurments:
Experiment_Inductance_vs_Weight_Ecoflex_Moldstar_incremental_statistical.xls

# Molds
The folder contains all the 3D files (.stl) of the used 3D printed molds in the paper.